import { useContext } from "react";
import { FlatList, Image, StyleSheet, Text, TouchableOpacity, View } from "react-native";
import { FriendsChatContext } from "./FriendsChatContext";
import SearchProfiles from "./SearchProfiles";

export default function Friends({ navigation }) {
  const { friends } = useContext(FriendsChatContext);

  const renderFriend = ({ item }) => (
    <TouchableOpacity
      style={styles.friendRow}
      onPress={() =>
        navigation.navigate("ProfilePage", { user: item })
      }
    >
      <Image source={item.profilePic} style={styles.friendImage} />
      <Text style={styles.friendName}>{item.name}</Text>
      <TouchableOpacity
        style={styles.messageButton}
        onPress={() => navigation.navigate("Message", { user: item })}
      >
        <Text style={styles.messageText}>Message</Text>
      </TouchableOpacity>
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      <SearchProfiles navigation={navigation} />
      <Text style={styles.title}>Your Friends</Text>
      <FlatList
        data={friends}
        renderItem={renderFriend}
        keyExtractor={(item) => item.id.toString()}
        ItemSeparatorComponent={() => <View style={styles.separator} />}
        ListEmptyComponent={<Text style={styles.empty}>You don't have any friends.</Text>}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#fff", padding: 16 },
  title: {
    fontSize: 24,
    fontWeight: "bold",
    marginBottom: 16,
    color: "#1877f2",
  },
  friendRow: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: 12,
    paddingHorizontal: 10,
    backgroundColor: "#f9f9f9",
    borderRadius: 8,
  },
  friendImage: {
    width: 50,
    height: 50,
    borderRadius: 25,
    marginRight: 12,
  },
  friendName: {
    flex: 1,
    fontSize: 16,
    fontWeight: "500",
    color: "#222",
  },
  messageButton: {
    backgroundColor: "#1877f2",
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 6,
  },
  messageText: {
    color: "#fff",
    fontSize: 14,
    fontWeight: "500",
  },
  separator: {
    height: 10,
  },
  empty: {
    textAlign: "center",
    color: "#888",
    marginTop: 40,
  },
});
