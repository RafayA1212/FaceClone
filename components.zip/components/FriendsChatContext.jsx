import { createContext } from "react";

export const FriendsChatContext = createContext({
  friends: [],
  setFriends: () => {},
  chats: {}, 
  setChats: () => {},
});
