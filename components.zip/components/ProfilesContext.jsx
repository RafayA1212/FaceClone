import { createContext } from "react";

export const ProfilesContext = createContext([
  { id: 2, name: "John Smith", profilePic: require("../assets/images/react-logo.png") , bio: "Coffee lover and React Native enthusiast." },
  { id: 3, name: "Alice Johnson", profilePic: require("../assets/images/react-logo.png") , bio: "Coffee lover and React Native enthusiast." },
  { id: 4, name: "Michael Brown", profilePic: require("../assets/images/react-logo.png") , bio: "Coffee lover and React Native enthusiast." },
  { id: 5, name: "Emily Davis", profilePic: require("../assets/images/react-logo.png") , bio: "Coffee lover and React Native enthusiast." },
  { id: 6, name: "David Wilson", profilePic: require("../assets/images/react-logo.png") , bio: "Coffee lover and React Native enthusiast." },
  { id: 7, name: "Sophia Martinez", profilePic: require("../assets/images/react-logo.png") , bio: "Coffee lover and React Native enthusiast." },
  { id: 8, name: "James Anderson", profilePic: require("../assets/images/react-logo.png") , bio: "Coffee lover and React Native enthusiast." },
  { id: 9, name: "Olivia Thomas", profilePic: require("../assets/images/react-logo.png") , bio: "Coffee lover and React Native enthusiast." },
  { id: 10, name: "Daniel Taylor", profilePic: require("../assets/images/react-logo.png") , bio: "Coffee lover and React Native enthusiast." },
  { id: 11, name: "Isabella Moore", profilePic: require("../assets/images/react-logo.png") , bio: "Coffee lover and React Native enthusiast." },
  { id: 12, name: "Matthew Jackson", profilePic: require("../assets/images/react-logo.png") , bio: "Coffee lover and React Native enthusiast." },
]);
